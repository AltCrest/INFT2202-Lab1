// namespace core
let core;